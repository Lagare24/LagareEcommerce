<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.6/css/dataTables.bootstrap5.css">
</head>


<body>
    All Products

    <table id="prodductsTable" class="table table-striped">
        <thead>
            <tr>
                <th>Product name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Qty</th>
                <th>Image</th>
                <th>Date created</th>
                <th>Date updated</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->productname); ?></td>
                    <td><?php echo e($product->productdescription); ?></td>
                    <td><?php echo e($product->price); ?></td>
                    <td><?php echo e($product->qty); ?></td>
                    <td><img src="<?php echo e($product->productimg); ?>" alt="<?php echo e($product->productimg); ?>" width="150px" height="150px"></td>
                    <td><?php echo e($product->created_at); ?></td>
                    <td><?php echo e($product->updated_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/2.0.6/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/2.0.6/js/dataTables.bootstrap5.js"></script>
    <script>
        $(document).ready(function () {
            $('#prodductsTable').DataTable();
        });
    </script>
</body>
</html><?php /**PATH C:\Users\Windows 10\Desktop\LagareECommerce\resources\views/index.blade.php ENDPATH**/ ?>