<div>
    <h1>About Page</h1>
</div><?php /**PATH C:\Users\Windows 10\Desktop\LagareECommerce\resources\views/about.blade.php ENDPATH**/ ?>