<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PagesController;
use App\Http\Controllers\ProductController;


// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/', [PagesController::class, 'about']);
Route::get('/', [ProductController::class, 'index']);
